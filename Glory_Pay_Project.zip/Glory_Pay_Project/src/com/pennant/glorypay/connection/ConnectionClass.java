package com.pennant.glorypay.connection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class ConnectionClass {
static JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	ConnectionClass.jdbcTemplate = jdbcTemplate;
}
public static JdbcTemplate getConnection(){
	return jdbcTemplate;
}
public void connectingToDb(){
	ApplicationContext context=new ClassPathXmlApplicationContext("com/pennant/glorypay/connection/connection.xml");
	context.getBean("edao",ConnectionClass.class);
	((AbstractApplicationContext)context).close();
}
}
