package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.glorypay.beans.Glory_Pay_Employees;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class AdmimLoginCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String uname = request.getParameter("ename");
		String password = request.getParameter("pwd");
		Glory_Pay_Employees emp=new Glory_Pay_Employees(password, uname);
		GloryPayDao dao=new GloryPayDaoImpl();
		Glory_Pay_Employees admin = dao.checkAminDetails(emp);
		if(admin!=null){
			try {
				response.sendRedirect("adminHome.jsp");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
