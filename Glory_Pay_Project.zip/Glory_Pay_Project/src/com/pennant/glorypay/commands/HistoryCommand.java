package com.pennant.glorypay.commands;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_History;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class HistoryCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		 GloryPayDao payDaoImpli = new GloryPayDaoImpl();
		 HttpSession session=request.getSession();
		 String mobile = (String)session.getAttribute("mobileNumber");
		 Glory_Pay_Loan_User_History user=new Glory_Pay_Loan_User_History(mobile);
			List<Glory_Pay_Loan_User_History> list = payDaoImpli.clearLoanDetails(user);
		
			request.setAttribute("loan_User_History", list);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/Clear_loan_User_Info.jsp");
			try {
				dispatcher.forward(request, response);
			} catch (ServletException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
