package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class CurrentLoans implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			HttpSession session = request.getSession();
			response.setContentType("text/html");
			String mobileNumber = (String) session.getAttribute("mobileNumber");
			PrintWriter out=response.getWriter();
			Glory_Pay_Loan_User_Details ebean = new Glory_Pay_Loan_User_Details();
			ebean.setMobile_Number(mobileNumber);

			GloryPayDao dao = new GloryPayDaoImpl();
			List<Glory_Pay_Loan_User_Details> rs = dao.currentLoan(ebean);
			if(rs.isEmpty()){
				out.println("<b style='color:green'>Currently we don't have pending loans</b>");
				out.print("<a href='HomePage.jsp'>click here</a>");
			}else{
			int i = 0;
			
			double interest = 0;
			
			double amount = 0.0;
			for (Glory_Pay_Loan_User_Details glory_Pay_Loan_User_Details : rs) {
				amount = glory_Pay_Loan_User_Details.getPaybleAmount();
				interest = amount + (amount * 0.05);
				request.setAttribute("amount"+i, interest);
				session.setAttribute("paid", amount);
			session.setAttribute("loanAmount", glory_Pay_Loan_User_Details.getLoanAmount());
			session.setAttribute("tenure", glory_Pay_Loan_User_Details.getTenure());
				 
				
				i++;
			}
			
			request.setAttribute("rows", rs);
			request.getRequestDispatcher("currentloan.jsp").forward(request, response);
			}
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
