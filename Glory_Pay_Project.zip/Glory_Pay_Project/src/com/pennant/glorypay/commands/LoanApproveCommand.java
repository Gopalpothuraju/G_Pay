package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.beans.Glory_Pay_Loans;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class LoanApproveCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.setContentType("text/html;charset=UTF-8");
			PrintWriter out = response.getWriter();
			String otp = request.getParameter("otp");
			HttpSession session = request.getSession();
			String mailOtp = (String) session.getAttribute("otp");
			if (mailOtp.equals(otp)) {

				String type_of_Loan = (String) session.getAttribute("loanType");
				String mobile = (String) session.getAttribute("mobileNumber");
				double loan_Amount = 0.0;
				@SuppressWarnings("unchecked")
				List<Glory_Pay_Loans> list = (List<Glory_Pay_Loans>) session.getAttribute("loanEligibility");
				for (Glory_Pay_Loans glory_Pay_Loans : list) {
					if (glory_Pay_Loans.getType_Of_Loan().equals(type_of_Loan)) {
						loan_Amount = glory_Pay_Loans.getLoan_Limit();
						break;
					}
				}
				double remaining_Amount = loan_Amount;
				double payable_Amount = 0.0;

				double tenure = 0;

				if (type_of_Loan.equalsIgnoreCase("simpleLoan")) {
					tenure = 30;
					payable_Amount = loan_Amount;
				} else {
					tenure = 365;
					payable_Amount = loan_Amount / 12;

				}

				String result = "Not-paid";
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				Date date = new Date(System.currentTimeMillis());
				String loan_Date = formatter.format(date);

				Glory_Pay_Loan_User_Details loanUserDetails = new Glory_Pay_Loan_User_Details(mobile, type_of_Loan,
						loan_Date, loan_Amount, result, payable_Amount, remaining_Amount, tenure);
				GloryPayDao dao = new GloryPayDaoImpl();
				if (!dao.insertLoanUserDetails(loanUserDetails)) {
					out.println(
							"<b style='color:green'>Your Loan is approved. Amount will be credited into your account</b>");
					out.print("<a href='HomePage.jsp'>click here</a>");

				} else {
					out.println("<b style='color:red'>Sorry..There is praising a problem..!!</b>");
					out.print("<a href='HomePage.jsp'>click here</a>");
				}
			} else {
				out.println("<b style='color:red'>Sorry..OTP is not matched..!!</b>");
				out.print("<a href='HomePage.jsp'>click here</a>");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
	}
}