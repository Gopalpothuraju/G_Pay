package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

@MultipartConfig
public class UpdatePhotoCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			response.setContentType("text/html;charset=UTF-8");
			HttpSession session = request.getSession();
			String mobile = (String) session.getAttribute("mobileNumber");
			Part img = request.getPart("profile_Image");
			GloryPayDao dao = new GloryPayDaoImpl();
			dao.updatePhoto(img, mobile);
			response.sendRedirect("HomePage.jsp");

		} catch (IOException | ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
