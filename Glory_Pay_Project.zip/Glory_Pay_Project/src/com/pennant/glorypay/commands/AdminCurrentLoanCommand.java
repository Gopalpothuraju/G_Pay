package com.pennant.glorypay.commands;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class AdminCurrentLoanCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
GloryPayDao dao=new GloryPayDaoImpl();
List<Glory_Pay_Loan_User_Details> list = dao.retreiveCurrentLoansForAdmin();
request.setAttribute("list", list);
try {
	request.getRequestDispatcher("adminDisplayCurrentLoans.jsp").forward(request, response);
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (ServletException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
