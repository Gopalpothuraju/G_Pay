package com.pennant.glorypay.commands;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class RetriveImageCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
	    try {
	    	Class.forName("oracle.jdbc.driver.OracleDriver");
	        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@pennantsrv13-03:1521:orcl","DB344","pass123");
            PreparedStatement ps = con.prepareStatement("select PROFILE_IMAGE from GLORY_PAY_USERS where MOBILENUMBER = ?");
           HttpSession session=request.getSession();
           String mobile = (String)session.getAttribute("mobileNumber");
            ps.setString(1, mobile);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
            Blob b = rs.getBlob("PROFILE_IMAGE");
            response.setContentType("image/jpeg");
            response.setContentLength((int) b.length());
            InputStream is = b.getBinaryStream();
            OutputStream os = response.getOutputStream();
            byte buf[] = new byte[(int) b.length()];
            is.read(buf);
            os.write(buf);
            os.close();
            }
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
	}

}
