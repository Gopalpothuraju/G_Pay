package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;
import com.pennant.glorypay.mails.GloryPayMail;

public class ForgetPasswordCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session=request.getSession();
		String value = request.getParameter("username");
		GloryPayDao dao=new GloryPayDaoImpl();
		int count=0;
		for (int j = 0; j < value.length(); j++) {
			if(value.charAt(j)=='@'){
				count++;
				break;
			}
		}
		if(count==0){
			Glory_Pay_Users users=new Glory_Pay_Users(value);
			Glory_Pay_Users applyLoan = dao.applyLoan(users);
			 value = applyLoan.getMail_Id();
		}
		session.setAttribute("forget", value);
		GloryPayMail mail=new GloryPayMail();
		
		try {
			mail.setMailServerProperties();
			mail.createEmailMessage(request, response);
			mail.sendEmail();
			response.sendRedirect("forgetotp.jsp");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
