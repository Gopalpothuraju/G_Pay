package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.beans.Glory_Pay_Loans;
import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class ApplyNowCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			HttpSession session = request.getSession();
			String mobile = (String) session.getAttribute("mobileNumber");
			Glory_Pay_Users user = new Glory_Pay_Users(mobile);
			Glory_Pay_Loan_User_Details ebean = new Glory_Pay_Loan_User_Details(mobile);
			GloryPayDao dao = new GloryPayDaoImpl();

			List<Glory_Pay_Loan_User_Details> list = dao.currentLoan(ebean);
			if (list.isEmpty()) {
				Glory_Pay_Users glory_Pay_Users = dao.applyLoan(user);
				if (glory_Pay_Users != null) {
					double ciBil_Score = glory_Pay_Users.getCiBil_Score();
					
					if (ciBil_Score <= 90.0) {
						Glory_Pay_Loans checkEligibilityForStudent = dao.checkEligibilityForStudent(ciBil_Score);
						List<Glory_Pay_Loans> checkEligibility = new ArrayList<>();
						double loan_Limit = checkEligibilityForStudent.getLoan_Limit();
						String type_Of_Loan = checkEligibilityForStudent.getType_Of_Loan();
						request.setAttribute("limit", loan_Limit);
						request.setAttribute("type_Of_Loan", type_Of_Loan);
						session.setAttribute("loanEligibility", checkEligibility);
						RequestDispatcher rd = request.getRequestDispatcher("ApplyNowForStudent.jsp");

						rd.forward(request, response);

					} else {
						List<Glory_Pay_Loans> checkEligibility = dao.checkEligibility(ciBil_Score);

						session.setAttribute("loanEligibility", checkEligibility);
						RequestDispatcher rd = request.getRequestDispatcher("ApplyNowForEmployee.jsp");

						rd.forward(request, response);

					}
				}
			} else {
				out.println("<b style='color:red'>Sorry..Your Previous loan is still pending..!!</b>");
				out.print("<a href='HomePage.jsp'>click here</a>");
			}
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
