package com.pennant.glorypay.commands;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.dao.GloryPayDao;
import com.pennant.glorypay.dao.GloryPayDaoImpl;

public class LoanPayCommand implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		try {
			PrintWriter out=response.getWriter();
			response.setContentType("text/html");
			
			String otp = request.getParameter("otp");
			HttpSession session=request.getSession();
			String mailOtp = (String)session.getAttribute("otp");
			String mobile=(String)session.getAttribute("mobileNumber");
			if(mailOtp.equals(otp)){
				Glory_Pay_Loan_User_Details ebean=new Glory_Pay_Loan_User_Details();
				ebean.setMobile_Number(mobile);
				double paidAmount = (double)session.getAttribute("paid");
				double loanAmount = (double)session.getAttribute("loanAmount");
				double remainingAmount=loanAmount-paidAmount;
				GloryPayDao dao=new GloryPayDaoImpl();
				double cibilScore=(double)session.getAttribute("cibilScore");
				 dao.increaseCibilScore(ebean,cibilScore);
				if(remainingAmount==0.0){
					 if(!dao.insertInHistory(ebean)){
						 
						int deleteInLoans = dao.deleteInLoans(ebean);
						if(deleteInLoans>0){
							dao.deleteDocs(ebean);
							out.println("Succesffully Paid");
							out.print("<a href='HomePage.jsp'>click here</a>");
						}
					 }
					
				}else{
					double tenure = (double)session.getAttribute("tenure");
					int loans = dao.updateInLoans(ebean,tenure,remainingAmount);
					if(loans>0){
						out.println("Succesffully Paid");
						out.print("<a href='HomePage.jsp'>click here</a>");
					}
				}
				
			}else{
				out.println("OTP is not matched");
				out.print("<a href='HomePage.jsp'>click here</a>");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	

}
}
