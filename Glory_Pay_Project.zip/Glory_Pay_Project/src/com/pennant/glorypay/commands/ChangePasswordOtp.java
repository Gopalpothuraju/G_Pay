package com.pennant.glorypay.commands;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ChangePasswordOtp implements Command {

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
	
		try {
			
			String otp = request.getParameter("otp");
			HttpSession session = request.getSession();
			String mailOtp = (String) session.getAttribute("otp");
			if (mailOtp.equals(otp)) {
			response.sendRedirect("newPassword.jsp");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
