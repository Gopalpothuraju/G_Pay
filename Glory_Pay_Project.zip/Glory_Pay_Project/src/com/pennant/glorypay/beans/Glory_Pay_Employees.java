package com.pennant.glorypay.beans;

public class Glory_Pay_Employees {

	private double id;
	private String email;
	private String userName;
	private String password;
	private double salary;
	
	public Glory_Pay_Employees(double id) {
		super();
		this.id = id;
	}


	public Glory_Pay_Employees(String password, String userName) {
		super();
		this.password = password;
		this.userName = userName;
	}


	public Glory_Pay_Employees(double id, String email, String userName, String password, double salary) {
		super();
		this.id = id;
		this.email = email;
		this.userName = userName;
		this.password = password;
		this.salary = salary;
	}
	

	public Glory_Pay_Employees() {
		super();
	}


	public double getId() {
		return id;
	}

	public void setId(double id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Glory_Pay_Employees [id=" + id + ", email=" + email + ", userName=" + userName + ", password="
				+ password + ", salary=" + salary + "]";
	}
	
}
	
