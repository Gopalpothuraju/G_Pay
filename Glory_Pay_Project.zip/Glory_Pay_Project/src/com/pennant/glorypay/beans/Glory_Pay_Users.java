package com.pennant.glorypay.beans;

import java.sql.Blob;

import javax.servlet.http.Part;


//glory pay user variables Details

public class Glory_Pay_Users {
	private String mobile_Number;
	private String aadhaar_Card;
	private String pan_Card;
	private String doJ;
	private String mail_Id;
	private String type_Of_User;
	private String doB;
	private Part profile_Image;
	private Blob profile;
	private double ciBil_Score;
	private String password;
	
	public Glory_Pay_Users() {
		// TODO Auto-generated constructor stub
	}
	public Glory_Pay_Users(String mobile_Number, String aadhaar_Card, String pan_Card, String doJ, String mail_Id,
			String type_Of_User, String doB, Part profile_Image, double ciBil_Score, String password) {
		super();
		this.mobile_Number = mobile_Number;
		this.aadhaar_Card = aadhaar_Card;
		this.pan_Card = pan_Card;
		this.doJ = doJ;
		this.mail_Id = mail_Id;
		this.type_Of_User = type_Of_User;
		this.doB = doB;
		this.profile_Image = profile_Image;
		this.ciBil_Score = ciBil_Score;
		this.password = password;
	}
	public Glory_Pay_Users(String mobile_Number, String aadhaar_Card, String pan_Card, String doJ, String mail_Id,
			String type_Of_User, String doB, Blob profile, double ciBil_Score, String password) {
		super();
		this.mobile_Number = mobile_Number;
		this.aadhaar_Card = aadhaar_Card;
		this.pan_Card = pan_Card;
		this.doJ = doJ;
		this.mail_Id = mail_Id;
		this.type_Of_User = type_Of_User;
		this.doB = doB;
		this.profile = profile;
		this.ciBil_Score = ciBil_Score;
		this.password = password;
	}
	
	public Glory_Pay_Users(String mobile_Number, String aadhaar_Card, String pan_Card, String doJ, String mail_Id,
			String type_Of_User, String doB, String password) {
		super();
		this.mobile_Number = mobile_Number;
		this.aadhaar_Card = aadhaar_Card;
		this.pan_Card = pan_Card;
		this.doJ = doJ;
		this.mail_Id = mail_Id;
		this.type_Of_User = type_Of_User;
		this.doB = doB;
		this.password = password;
	}
	public Glory_Pay_Users(String mail_Id, String password) {
		super();
		this.mail_Id = mail_Id;
		this.password = password;
	}
	public Glory_Pay_Users(String mobile_Number) {
		super();
		this.mobile_Number = mobile_Number;
	}
	public String getMobile_Number() {
		return mobile_Number;
	}
	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}
	public String getAadhaar_Card() {
		return aadhaar_Card;
	}
	public void setAadhaar_Card(String aadhaar_Card) {
		this.aadhaar_Card = aadhaar_Card;
	}
	public String getPan_Card() {
		return pan_Card;
	}
	public void setPan_Card(String pan_Card) {
		this.pan_Card = pan_Card;
	}
	public String getDoJ() {
		return doJ;
	}
	public void setDoJ(String doJ) {
		this.doJ = doJ;
	}
	public String getMail_Id() {
		return mail_Id;
	}
	public void setMail_Id(String mail_Id) {
		this.mail_Id = mail_Id;
	}
	public String getType_Of_User() {
		return type_Of_User;
	}
	public void setType_Of_User(String type_Of_User) {
		this.type_Of_User = type_Of_User;
	}
	public String getDoB() {
		return doB;
	}
	public void setDoB(String doB) {
		this.doB = doB;
	}
	public Part getProfile_Image() {
		return profile_Image;
	}
	public void setProfile_Image(Part profile_Image) {
		this.profile_Image = profile_Image;
	}
	public Blob getProfile() {
		return profile;
	}
	public void setProfile(Blob profile) {
		this.profile = profile;
	}
	public double getCiBil_Score() {
		return ciBil_Score;
	}
	public void setCiBil_Score(double ciBil_Score) {
		this.ciBil_Score = ciBil_Score;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Glory_Pay_Users [mobile_Number=" + mobile_Number + ", aadhaar_Card=" + aadhaar_Card + ", pan_Card="
				+ pan_Card + ", doJ=" + doJ + ", mail_Id=" + mail_Id + ", type_Of_User=" + type_Of_User + ", doB=" + doB
				+ ", profile_Image=" + profile_Image + ", profile=" + profile + ", ciBil_Score=" + ciBil_Score
				+ ", password=" + password + "]";
	}
	
	
	

}
