package com.pennant.glorypay.beans;

public class Glory_Pay_Loan_User_History {
	private String mobile_Number;
	private String typeOfLoan;
	private String loanDate;
	private String paidDate;
	private double loanAmount;
	private String remarks;
	public Glory_Pay_Loan_User_History(String mobile_Number, String typeOfLoan, String loanDate, String paidDate,
			double loanAmount, String remarks) {
		super();
		this.mobile_Number = mobile_Number;
		this.typeOfLoan = typeOfLoan;
		this.loanDate = loanDate;
		this.paidDate = paidDate;
		this.loanAmount = loanAmount;
		this.remarks = remarks;
	}
	public Glory_Pay_Loan_User_History() {
		super();
	}
	public Glory_Pay_Loan_User_History(String mobile_Number) {
		super();
		this.mobile_Number = mobile_Number;
	}
	public String getMobile_Number() {
		return mobile_Number;
	}
	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}
	public String getTypeOfLoan() {
		return typeOfLoan;
	}
	public void setTypeOfLoan(String typeOfLoan) {
		this.typeOfLoan = typeOfLoan;
	}
	public String getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(String loanDate) {
		this.loanDate = loanDate;
	}
	public String getPaidDate() {
		return paidDate;
	}
	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Glory_Pay_Loan_User_History [mobile_Number=" + mobile_Number + ", typeOfLoan=" + typeOfLoan
				+ ", loanDate=" + loanDate + ", paidDate=" + paidDate + ", loanAmount=" + loanAmount + ", remarks="
				+ remarks + "]";
	}
	
	
	
	
	

}
