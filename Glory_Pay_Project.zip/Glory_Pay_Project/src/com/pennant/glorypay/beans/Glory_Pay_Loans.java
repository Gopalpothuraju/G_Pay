package com.pennant.glorypay.beans;
/*
 * G-Pay loan details	
 */

public class Glory_Pay_Loans {

	private String type_Of_Loan;
	private double loan_Limit;
	private double low_Cibil_Score;
	private double high_Cibil_Score;
	public Glory_Pay_Loans() {
		// TODO Auto-generated constructor stub
	}
	public Glory_Pay_Loans(String type_Of_Loan, double loan_Limit, double low_Cibil_Score, double high_Cibil_Score) {
		super();
		this.type_Of_Loan = type_Of_Loan;
		this.loan_Limit = loan_Limit;
		this.low_Cibil_Score = low_Cibil_Score;
		this.high_Cibil_Score = high_Cibil_Score;
	}
	public String getType_Of_Loan() {
		return type_Of_Loan;
	}
	public void setType_Of_Loan(String type_Of_Loan) {
		this.type_Of_Loan = type_Of_Loan;
	}
	public double getLoan_Limit() {
		return loan_Limit;
	}
	public void setLoan_Limit(double loan_Limit) {
		this.loan_Limit = loan_Limit;
	}
	public double getLow_Cibil_Score() {
		return low_Cibil_Score;
	}
	public void setLow_Cibil_Score(double low_Cibil_Score) {
		this.low_Cibil_Score = low_Cibil_Score;
	}
	public double getHigh_Cibil_Score() {
		return high_Cibil_Score;
	}
	public void setHigh_Cibil_Score(double high_Cibil_Score) {
		this.high_Cibil_Score = high_Cibil_Score;
	}
	@Override
	public String toString() {
		return "Glory_Pay_Loans [type_Of_Loan=" + type_Of_Loan + ", loan_Limit=" + loan_Limit + ", low_Cibil_Score="
				+ low_Cibil_Score + ", high_Cibil_Score=" + high_Cibil_Score + "]";
	}
	
	
}
