package com.pennant.glorypay.mails;


import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class GloryPayMail {

	Properties emailProperties;
	Session mailSession;
	MimeMessage emailMessage;
	Random r=new Random();
	public String otp=null;
	/*public static void main(String args[]) throws AddressException,
			MessagingException {

		GloryPayMail javaEmail = new GloryPayMail();

		javaEmail.setMailServerProperties();
		javaEmail.createEmailMessage();
		javaEmail.sendEmail();
	}
*/
	public void setMailServerProperties() {

		String emailPort = "587";//gmail's smtp port

		emailProperties = System.getProperties();
		emailProperties.put("mail.smtp.port", emailPort);
		emailProperties.put("mail.smtp.auth", "true");
		emailProperties.put("mail.smtp.starttls.enable", "true");

	}

	public void createEmailMessage(HttpServletRequest request,HttpServletResponse response) throws AddressException,
			MessagingException {
		HttpSession session=request.getSession();
		String email = (String)session.getAttribute("userName");
		if(email==null){
			email=(String)session.getAttribute("forget");
		}
		String[] toEmails = { email };
		String emailSubject = "OTP";
		
		int otp1 = r.nextInt(999999)+100000;
		 otp=otp1+"";
		String emailBody = otp;
		session.setAttribute("otp", otp);
		mailSession = Session.getDefaultInstance(emailProperties, null);
		emailMessage = new MimeMessage(mailSession);

		for (int i = 0; i < toEmails.length; i++) {
			emailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(toEmails[i]));
		}

		emailMessage.setSubject(emailSubject);
		emailMessage.setContent(emailBody, "text/html");//for a html email
		//emailMessage.setText(emailBody);// for a text email

	}

	public void sendEmail() throws AddressException, MessagingException {

		String emailHost = "smtp.gmail.com";
		String fromUser = "glorypayofficialsite";//just the id alone without @gmail.com
		String fromUserEmailPassword = "GloryPay123";

		Transport transport = mailSession.getTransport("smtp");

		transport.connect(emailHost, fromUser, fromUserEmailPassword);
		transport.sendMessage(emailMessage, emailMessage.getAllRecipients());
		transport.close();
		
	}
}
