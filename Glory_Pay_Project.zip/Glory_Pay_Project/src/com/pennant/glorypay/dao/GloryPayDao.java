package com.pennant.glorypay.dao;

import java.util.List;

import javax.servlet.http.Part;

import com.pennant.glorypay.beans.Glory_Pay_Docs_Verify;
import com.pennant.glorypay.beans.Glory_Pay_Employees;
import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.beans.Glory_Pay_Loan_User_History;
import com.pennant.glorypay.beans.Glory_Pay_Loans;
import com.pennant.glorypay.beans.Glory_Pay_Users;

public interface GloryPayDao {

	public abstract Glory_Pay_Users checkValidUser(Glory_Pay_Users users);
	public abstract boolean insertUser(Glory_Pay_Users users);
	public abstract Glory_Pay_Users applyLoan(Glory_Pay_Users users);
	public abstract Glory_Pay_Loans checkEligibilityForStudent(double ciBil_Score);
	public abstract List<Glory_Pay_Loans> checkEligibility(double ciBil_Score);
	public abstract boolean insertLoanUserDetails(Glory_Pay_Loan_User_Details loanUserDetails);
	public abstract List<Glory_Pay_Loan_User_Details> currentLoan(Glory_Pay_Loan_User_Details ebean);

	public abstract boolean insertInHistory(Glory_Pay_Loan_User_Details ebean);
	public abstract int deleteInLoans(Glory_Pay_Loan_User_Details ebean);
	public abstract int updateInLoans(Glory_Pay_Loan_User_Details ebean, double tenure, double remainingAmount);
	public abstract List<Glory_Pay_Loan_User_History> clearLoanDetails(Glory_Pay_Loan_User_History user);
	public abstract int increaseCibilScore(Glory_Pay_Loan_User_Details ebean, double cibilScore);
	public abstract boolean insertDocuments(Glory_Pay_Docs_Verify user);
	
	public abstract int updatePassword(String pwd, String email);
	public abstract Glory_Pay_Users updateUsers(Glory_Pay_Users users);
	public abstract boolean updatePhoto(Part img, String mobile);
	public abstract boolean updateUserDetails(Glory_Pay_Users user);
	public abstract int deleteDocs(Glory_Pay_Loan_User_Details ebean);
	public abstract Glory_Pay_Employees checkAminDetails(Glory_Pay_Employees emp);
	public abstract List<Glory_Pay_Loan_User_Details> retreiveCurrentLoansForAdmin();
	public abstract List<Glory_Pay_Loan_User_History> retreiveClearLoansForAdmin();
}
