package com.pennant.glorypay.dao;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Part;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.pennant.glorypay.beans.Glory_Pay_Docs_Verify;
import com.pennant.glorypay.beans.Glory_Pay_Employees;
import com.pennant.glorypay.beans.Glory_Pay_Loan_User_Details;
import com.pennant.glorypay.beans.Glory_Pay_Loan_User_History;
import com.pennant.glorypay.beans.Glory_Pay_Loans;
import com.pennant.glorypay.beans.Glory_Pay_Users;
import com.pennant.glorypay.connection.ConnectionClass;

public class GloryPayDaoImpl implements GloryPayDao {
	JdbcTemplate jdbcTemplate = null;

	public GloryPayDaoImpl() {
		ConnectionClass con = new ConnectionClass();
		con.connectingToDb();
		jdbcTemplate = ConnectionClass.getConnection();
	}

	@Override
	public Glory_Pay_Users checkValidUser(Glory_Pay_Users users) {
		String sql = "select * from Glory_pay_Users where MAIL_ID ='" + users.getMail_Id() + "' and password='"
				+ users.getPassword() + "'";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Glory_Pay_Users>() {

			@Override
			public Glory_Pay_Users mapRow(ResultSet rs, int num) throws SQLException {
				Glory_Pay_Users user = new Glory_Pay_Users();
				user.setMobile_Number(rs.getString(1));
				user.setAadhaar_Card(rs.getString(2));
				user.setPan_Card(rs.getString(3));
				user.setDoJ(rs.getDate(4) + "");
				user.setMail_Id(rs.getString(5));
				user.setType_Of_User(rs.getString(6));
				user.setDoB(rs.getDate(7) + "");
				user.setPassword(rs.getString(9));
				user.setCiBil_Score(rs.getDouble(10));
				return user;
			}
		});
	}

	@Override
	public boolean insertUser(Glory_Pay_Users users) {
		String query = "select MAIL_ID,MOBILENUMBER from GLORY_PAY_USERS ";
		SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet(query);
		int count = 0;
		while (queryForRowSet.next()) {
			if (queryForRowSet.getString(2).equals(users.getMobile_Number())) {
				count++;
				break;
			}
		}
		if (count > 0) {

			return false;
		} else {
			return jdbcTemplate.execute("insert into GLORY_PAY_USERS values(?,?,?,?,?,?,?,?,?,?)",
					new PreparedStatementCallback<Boolean>() {

						@Override
						public Boolean doInPreparedStatement(PreparedStatement pst)
								throws SQLException, DataAccessException {

							pst.setString(1, users.getMobile_Number());
							pst.setString(2, users.getAadhaar_Card());
							pst.setString(3, users.getPan_Card());
							pst.setDate(4, Date.valueOf(users.getDoJ()));
							pst.setString(5, users.getMail_Id());
							pst.setString(6, users.getType_Of_User());
							pst.setDate(7, Date.valueOf(users.getDoB()));
							try {
								pst.setBinaryStream(8, users.getProfile_Image().getInputStream(),
										(int) users.getProfile_Image().getSize());
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							pst.setString(9, users.getPassword());
							pst.setDouble(10, users.getCiBil_Score());
							return pst.execute();

						}
					});

		}
	}

	@Override
	public Glory_Pay_Users applyLoan(Glory_Pay_Users users) {
		String sql = "select * from GLORY_PAY_USERS where MOBILENUMBER ='" + users.getMobile_Number() + "'";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Glory_Pay_Users>() {

			@Override
			public Glory_Pay_Users mapRow(ResultSet rs, int num) throws SQLException {
				Glory_Pay_Users user = new Glory_Pay_Users();
				user.setMobile_Number(rs.getString(1));
				user.setAadhaar_Card(rs.getString(2));
				user.setPan_Card(rs.getString(3));
				user.setDoJ(rs.getDate(4) + "");
				user.setMail_Id(rs.getString(5));
				user.setType_Of_User(rs.getString(6));
				user.setDoB(rs.getDate(7) + "");
				user.setPassword(rs.getString(9));
				user.setCiBil_Score(rs.getDouble(10));
				return user;
			}

		});

	}

	@Override
	public Glory_Pay_Loans checkEligibilityForStudent(double ciBil_Score) {

		String sql = "select * from GLORY_PAY_LOANS where LOW_CIBIL_SCORE >=" + ciBil_Score + " and HIGH_CIBIL_SCORE<="
				+ (ciBil_Score + 10);
		return jdbcTemplate.queryForObject(sql, new RowMapper<Glory_Pay_Loans>() {

			@Override
			public Glory_Pay_Loans mapRow(ResultSet rs, int arg1) throws SQLException {
				Glory_Pay_Loans loan = new Glory_Pay_Loans();
				loan.setType_Of_Loan(rs.getString(1));
				loan.setLoan_Limit(rs.getDouble(2));
				loan.setLow_Cibil_Score(rs.getDouble(3));
				loan.setHigh_Cibil_Score(rs.getDouble(4));
				return loan;
			}
		});
	}

	@Override
	public List<Glory_Pay_Loans> checkEligibility(double ciBil_Score) {
		String query = "select * from GLORY_PAY_LOANS where LOW_CIBIL_SCORE >=" + ciBil_Score
				+ " and HIGH_CIBIL_SCORE<=" + (ciBil_Score + 100);

		List<Glory_Pay_Loans> glory_pay_loans = new ArrayList<>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(query);
		for (Map<String, Object> rs : rows) {
			Glory_Pay_Loans loan = new Glory_Pay_Loans();
			loan.setType_Of_Loan((String) rs.get("TYPE_OF_LOAN"));

			loan.setLoan_Limit(((BigDecimal) rs.get("LIMIT")).doubleValue());

			loan.setLow_Cibil_Score(((BigDecimal) rs.get("LOW_CIBIL_SCORE")).doubleValue());
			loan.setHigh_Cibil_Score(((BigDecimal) rs.get("HIGH_CIBIL_SCORE")).doubleValue());
			glory_pay_loans.add(loan);
		}
		return glory_pay_loans;
	}

	@Override
	public boolean insertLoanUserDetails(Glory_Pay_Loan_User_Details loanUserDetails) {
		String query = "insert into GLORY_PAY_LOAN_USER_DETAILS values(?,?,?,?,?,?,?,?)";
		return jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement pst) throws SQLException, DataAccessException {
				pst.setString(1, loanUserDetails.getMobile_Number());
				pst.setString(2, loanUserDetails.getTypeOfLoan());

				pst.setDate(3, Date.valueOf(loanUserDetails.getDateOfLOAN()));

				pst.setDouble(4, loanUserDetails.getLoanAmount());
				pst.setString(5, loanUserDetails.getResult());
				pst.setDouble(6, loanUserDetails.getPaybleAmount());
				pst.setDouble(7, loanUserDetails.getRemainingAmount());
				pst.setDouble(8, loanUserDetails.getTenure());
				return pst.execute();
			}
		});
	}

	@Override
	public List<Glory_Pay_Loan_User_Details> currentLoan(Glory_Pay_Loan_User_Details ebean) {
		String sql = "select * from GLORY_PAY_LOAN_USER_DETAILS where MOBILENUMBER ='" + ebean.getMobile_Number() + "'";
		List<Glory_Pay_Loan_User_Details> glory_pay_users = new ArrayList<>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> rs : rows) {
			Glory_Pay_Loan_User_Details user = new Glory_Pay_Loan_User_Details();

			user.setMobile_Number((String) rs.get("MOBILENUMBER"));
			user.setTypeOfLoan((String) rs.get("TYPE_OF_LOAN"));
			user.setDateOfLOAN(((Timestamp) rs.get("LOAN_DATE")).toString());
			user.setLoanAmount(((BigDecimal) rs.get("LOAN_AMOUNT")).doubleValue());
			user.setResult((String) rs.get("RESULT"));
			user.setPaybleAmount(((BigDecimal) rs.get("PAYABLE_AMOUNT")).doubleValue());
			user.setRemainingAmount(((BigDecimal) rs.get("REMAINING_AMOUNT")).doubleValue());
			user.setTenure(((BigDecimal) rs.get("TENURE")).doubleValue());
			glory_pay_users.add(user);
		}
		return glory_pay_users;
	}

	@Override
	public boolean insertInHistory(Glory_Pay_Loan_User_Details ebean) {
		boolean flag = false;
		List<Glory_Pay_Loan_User_Details> currentLoan = currentLoan(ebean);
		String query = "insert into GLORY_PAY_LOAN_USER_HISTORY values(?,?,?,?,?,?)";
		for (Glory_Pay_Loan_User_Details glory_Pay_Loan_User_Details : currentLoan) {

			flag = jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {

				@Override
				public Boolean doInPreparedStatement(PreparedStatement pst) throws SQLException, DataAccessException {

					pst.setString(1, glory_Pay_Loan_User_Details.getMobile_Number());
					pst.setString(2, glory_Pay_Loan_User_Details.getTypeOfLoan());
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					String dda[] = glory_Pay_Loan_User_Details.getDateOfLOAN().split("\\s");
					pst.setDate(3, Date.valueOf(dda[0]));
					Date date = new Date(System.currentTimeMillis());
					String doj = formatter.format(date);
					pst.setDate(4, Date.valueOf(doj));
					pst.setString(5, "Paid");
					pst.setDouble(6, glory_Pay_Loan_User_Details.getLoanAmount());

					return pst.execute();
				}
			});
		}
		return flag;
	}

	@Override
	public int deleteInLoans(Glory_Pay_Loan_User_Details ebean) {
		String sql = "delete from GLORY_PAY_LOAN_USER_DETAILS where MOBILENUMBER ='" + ebean.getMobile_Number() + "'";

		return jdbcTemplate.update(sql);
	}

	@Override
	public int updateInLoans(Glory_Pay_Loan_User_Details ebean, double tenure,double remainingAmount) {

		String query = "update Glory_Pay_Loan_User_Details set TENURE=" + (tenure - 30) + ",REMAINING_AMOUNT="+remainingAmount+" where MOBILENUMBER='"
				+ ebean.getMobile_Number() + "'";

		return jdbcTemplate.update(query);
	}

	@Override
	public List<Glory_Pay_Loan_User_History> clearLoanDetails(Glory_Pay_Loan_User_History user) {
		String sql = "select * from GLORY_PAY_LOAN_USER_HISTORY WHERE MOBILENUMBER='" + user.getMobile_Number() + "'";
		List<Glory_Pay_Loan_User_History> glory_pay_users = new ArrayList<>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> map : rows) {
			Glory_Pay_Loan_User_History loan_User_History = new Glory_Pay_Loan_User_History();
			// users.setMail_Id((String) map.get("mail_Id"));
			loan_User_History.setMobile_Number((String) map.get("MOBILENUMBER"));
			loan_User_History.setLoanAmount(((BigDecimal) map.get("LOAN_AMOUNT")).doubleValue());

			loan_User_History.setLoanDate(((Timestamp) map.get("LOAN_DATE")).toString());
			loan_User_History.setPaidDate(((Timestamp) map.get("PAID_DATE")).toString());
			loan_User_History.setRemarks((String) map.get("REMARKS"));
			loan_User_History.setTypeOfLoan((String) map.get("TYPE_OF_LOAN"));

			glory_pay_users.add(loan_User_History);
		}
		return glory_pay_users;
	}

	@Override
	public int increaseCibilScore(Glory_Pay_Loan_User_Details ebean, double cibilScore) {
		if(cibilScore>100){
		if(cibilScore>850){
			
		}
		else{
			cibilScore=(cibilScore +50);
		}
		}else{
			if(cibilScore>80){
				
			}else{
				cibilScore=cibilScore+5;
			}
		}
		String query = "update GLORY_PAY_USERS set CIBIL_SCORE=" + cibilScore + " where MOBILENUMBER='"
				+ ebean.getMobile_Number() + "'";

		return jdbcTemplate.update(query);
	}

	@Override
	public boolean insertDocuments(Glory_Pay_Docs_Verify users) {
		return jdbcTemplate.execute("insert into GLORY_PAY_DOCS_VERIFY values(?,?,?,?,?)",
				new PreparedStatementCallback<Boolean>() {

					@Override
					public Boolean doInPreparedStatement(PreparedStatement pst)
							throws SQLException, DataAccessException {

						pst.setString(1, users.getMobile_Number());
						pst.setString(2, users.getEmployee_Id());
						try {
							pst.setBinaryStream(3, users.getOffer_Letter().getInputStream(),
									(int) users.getOffer_Letter().getSize());
							pst.setBinaryStream(4, users.getPay_Slip().getInputStream(),
									(int) users.getPay_Slip().getSize());
							pst.setBinaryStream(5, users.getBank_Statement().getInputStream(),
									(int) users.getBank_Statement().getSize());
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						return pst.execute();

					}
				});
	}

	@Override
	public int updatePassword(String pwd, String email) {
		String query = "update GLORY_PAY_USERS set PASSWORD='" + pwd + "' where MAIL_ID='" + email + "'";

		return jdbcTemplate.update(query);
	}

	public Glory_Pay_Users updateUsers(Glory_Pay_Users users) {
		String sql = "select * from Glory_Pay_Users where MOBILENUMBER ='" + users.getMobile_Number() + "'";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Glory_Pay_Users>() {

			@Override
			public Glory_Pay_Users mapRow(ResultSet rs, int num) throws SQLException {
				Glory_Pay_Users user = new Glory_Pay_Users();
				user.setMobile_Number(rs.getString(1));
				user.setAadhaar_Card(rs.getString(2));
				user.setPan_Card(rs.getString(3));
				user.setDoJ(rs.getDate(4) + "");
				user.setMail_Id(rs.getString(5));
				user.setType_Of_User(rs.getString(6));
				user.setDoB(rs.getDate(7) + "");
				user.setProfile(rs.getBlob(8));
				user.setPassword(rs.getString(9));
				
				user.setCiBil_Score(rs.getDouble(10));

				return user;
			}
		});
	}

	@Override
	public boolean updatePhoto(Part img, String mobile) {
		String query = "update GLORY_PAY_USERS set PROFILE_IMAGE=? where MOBILENUMBER=?";
		return jdbcTemplate.execute(query, new PreparedStatementCallback<Boolean>() {

			@Override
			public Boolean doInPreparedStatement(PreparedStatement pst) throws SQLException, DataAccessException {
				try {
					pst.setBinaryStream(1, img.getInputStream(),
							(int) img.getSize());
					pst.setString(2, mobile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return pst.execute();
			}
		});
		
	}

	@Override
	public boolean updateUserDetails(Glory_Pay_Users users) {
		return jdbcTemplate.execute("update GLORY_PAY_USERS set MOBILENUMBER=?,AADHAARCARD=?,PANCARD=?,DOJ=?,MAIL_ID=?,TYPE_OF_USER=?,DOB=?,PASSWORD=? where MOBILENUMBER=?",
				new PreparedStatementCallback<Boolean>() {

					@Override
					public Boolean doInPreparedStatement(PreparedStatement pst)
							throws SQLException, DataAccessException {

						pst.setString(1, users.getMobile_Number());
						pst.setString(2, users.getAadhaar_Card());
						pst.setString(3, users.getPan_Card());
						pst.setDate(4, Date.valueOf(users.getDoJ()));
						pst.setString(5, users.getMail_Id());
						pst.setString(6, users.getType_Of_User());
						pst.setDate(7, Date.valueOf(users.getDoB()));
						pst.setString(8, users.getPassword());
						pst.setString(9, users.getMobile_Number());
						return pst.execute();

					}
				});
	}

	@Override
	public int deleteDocs(Glory_Pay_Loan_User_Details ebean) {
		String sql = "delete from GLORY_PAY_DOCS_VERIFY where MOBILENUMBER ='" + ebean.getMobile_Number() + "'";

		return jdbcTemplate.update(sql);
	}

	@Override
	public Glory_Pay_Employees checkAminDetails(Glory_Pay_Employees emp) {
		String sql = "select * from GLORY_PAY_EMPLOYEES where USENAME ='" + emp.getUserName() + "' and PASSWORD='"
				+ emp.getPassword() + "'";
		return jdbcTemplate.queryForObject(sql, new RowMapper<Glory_Pay_Employees>() {

			@Override
			public Glory_Pay_Employees mapRow(ResultSet rs, int num) throws SQLException {
				Glory_Pay_Employees admin = new Glory_Pay_Employees();
				admin.setEmail(rs.getString(2));
				admin.setUserName(rs.getString(3));
				return admin;
			}
		});
	}

	

	@Override
	public List<Glory_Pay_Loan_User_Details> retreiveCurrentLoansForAdmin() {
		String sql = "select * from GLORY_PAY_LOAN_USER_DETAILS";
		List<Glory_Pay_Loan_User_Details> glory_pay_users = new ArrayList<>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> rs : rows) {
			Glory_Pay_Loan_User_Details user = new Glory_Pay_Loan_User_Details();

			user.setMobile_Number((String) rs.get("MOBILENUMBER"));
			user.setTypeOfLoan((String) rs.get("TYPE_OF_LOAN"));
			user.setDateOfLOAN(((Timestamp) rs.get("LOAN_DATE")).toString());
			user.setLoanAmount(((BigDecimal) rs.get("LOAN_AMOUNT")).doubleValue());
			user.setResult((String) rs.get("RESULT"));
			user.setPaybleAmount(((BigDecimal) rs.get("PAYABLE_AMOUNT")).doubleValue());
			user.setRemainingAmount(((BigDecimal) rs.get("REMAINING_AMOUNT")).doubleValue());
			user.setTenure(((BigDecimal) rs.get("TENURE")).doubleValue());
			glory_pay_users.add(user);
		}
		return glory_pay_users;
	}

	@Override
	public List<Glory_Pay_Loan_User_History> retreiveClearLoansForAdmin() {
		String sql = "select * from GLORY_PAY_LOAN_USER_HISTORY";
		List<Glory_Pay_Loan_User_History> glory_pay_users = new ArrayList<>();

		List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);

		for (Map<String, Object> map : rows) {
			Glory_Pay_Loan_User_History loan_User_History = new Glory_Pay_Loan_User_History();
			// users.setMail_Id((String) map.get("mail_Id"));
			loan_User_History.setMobile_Number((String) map.get("MOBILENUMBER"));
			loan_User_History.setLoanAmount(((BigDecimal) map.get("LOAN_AMOUNT")).doubleValue());

			loan_User_History.setLoanDate(((Timestamp) map.get("LOAN_DATE")).toString());
			loan_User_History.setPaidDate(((Timestamp) map.get("PAID_DATE")).toString());
			loan_User_History.setRemarks((String) map.get("REMARKS"));
			loan_User_History.setTypeOfLoan((String) map.get("TYPE_OF_LOAN"));

			glory_pay_users.add(loan_User_History);
		}
		return glory_pay_users;
	}
}
