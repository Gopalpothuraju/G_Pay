package com.pennant.glorypay.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.glorypay.commands.AdmimLoginCommand;
import com.pennant.glorypay.commands.AdminClearLoanCommand;
import com.pennant.glorypay.commands.AdminCurrentLoanCommand;
import com.pennant.glorypay.commands.ApplyNowCommand;
import com.pennant.glorypay.commands.ChangePasswordOtp;
import com.pennant.glorypay.commands.Command;
import com.pennant.glorypay.commands.CurrentLoans;
import com.pennant.glorypay.commands.ForgetPasswordCommand;
import com.pennant.glorypay.commands.HistoryCommand;
import com.pennant.glorypay.commands.LoanApproveCommand;
import com.pennant.glorypay.commands.LoanPayCommand;
import com.pennant.glorypay.commands.LoanProceedCommand;
import com.pennant.glorypay.commands.LoginCommand;
import com.pennant.glorypay.commands.NewPasswordCommand;
import com.pennant.glorypay.commands.PaymentCommand;
import com.pennant.glorypay.commands.RetriveImageCommand;
import com.pennant.glorypay.commands.SignUpCommand;
import com.pennant.glorypay.commands.UpdateCommand;
import com.pennant.glorypay.commands.UpdateDetailsCommand;
import com.pennant.glorypay.commands.UpdatePhotoCommand;




@WebServlet("/GloryPayServlet")
@MultipartConfig
public class GloryPayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public GloryPayServlet() {
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Map<String, Command> mapping=new HashMap<>();
		mapping.put("signup", new SignUpCommand());
		mapping.put("login",new LoginCommand());
		mapping.put("applyforloan", new ApplyNowCommand());
		mapping.put("proceedLoan", new LoanProceedCommand());
		mapping.put("approveLoan", new LoanApproveCommand());
		mapping.put("currentloans", new CurrentLoans());
		mapping.put("payment", new PaymentCommand());
		mapping.put("loanpay", new LoanPayCommand());
		mapping.put("history", new HistoryCommand());
		mapping.put("forgetPassword", new ForgetPasswordCommand());
		mapping.put("changepassword", new ChangePasswordOtp());
		mapping.put("newpassword", new NewPasswordCommand());
		mapping.put("profile", new UpdateCommand());
		mapping.put("profileImage", new RetriveImageCommand());
		mapping.put("photoUpdate", new UpdatePhotoCommand());
		mapping.put("retrieve", new UpdateDetailsCommand());
		mapping.put("adminlogin", new AdmimLoginCommand());
		mapping.put("admincurrentloans", new AdminCurrentLoanCommand());
		mapping.put("adminclearloans", new AdminClearLoanCommand());
		String url = request.getParameter("url");
		Command command=mapping.get(url);
		command.doGet(request, response);
	}

}
